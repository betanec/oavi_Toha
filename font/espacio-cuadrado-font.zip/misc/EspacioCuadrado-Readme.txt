Terms of use:
Free for personal use only.
For commercial purposes please make a donation.
I would like to see how you use my fonts. Please send me an email with your designs to RANGELCASTRO@HOTMAIL.COM
Thanks for the download!!!...Enjoy!!! 	~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
T�rminos de uso:
Gratis solamente para uso personal.
Para fines comerciales por favor haga una donaci�n.
Me gustar�a ver como usa mi tipograf�a. Por favor env�e un email con sus dise�os a RANGELCASTRO@HOTMAIL.COM
Gracias por descargar!!!...Que lo disfrute!!!