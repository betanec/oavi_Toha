OTF: Banbury (Regular and Italic)
Dennis Ludlow 2017 all rights reserved
by Sharkshock 
dennis@sharkshock.net


Thanks for taking a look! Banbury is a Neo Classical display font inspired by traditional English bold typefaces. The thick line weights paired with hairline serifs create contrast for
an elegant and dynamic look. Use Banbury for a luxury logo, publishing, or movie poster. Basic/extended latin, punctuation, European accents, diacritics, ligatures, 80% small caps, 
kerning, and Italic are included in the full versions. The demo version contains basic latin, numbers, and very limited kerning. 

The complete versions are available by $25 donation or purchase of a commercial license. Please visit www.sharkshock.net/license for more information on this. This $25 is for personal
use only and does NOT constitute a commercial license. 

All of my fonts may be distributed for free so long as the readme file stays intact. Thank you for your support!

visit www.sharkshock.net for more and take a bite out of BORING design!

tags: display, font, typeface, publishing, logo, title, book, diacritics, French, Polish, Sharkshock, German, Portuguese, European, serif, neo-classical, weight, body, England, London,
British, Europe, latin, ligatures, kerning, art, classic, classical



